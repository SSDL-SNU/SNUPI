------------------------------------------------------------------------------------------
* SNUPI(Structured Nucleic Acids Programming Interface)
------------------------------------------------------------------------------------------
- SNUPI is a multiscale analysis framework based on the finite element model 
	with the intrinsic properties of DNA characterized by molecular dynamics simulations.
- GitHub link:	https://github.com/SSDL-SNU/SNUPI

------------------------------------------------------------------------------------------
* Update (v3.00)
------------------------------------------------------------------------------------------
- Some features are implemented
	+ Dynamic simulations
	+ Restarting simulations
	+ GPU acceleration
- Required version of MATLAB Runtime is changed: R2019a (9.6) -> R2022b (9.13)

------------------------------------------------------------------------------------------
* Pre-requisite
------------------------------------------------------------------------------------------
- The correct version of the MATLAB Runtime should be installed.
- Required runtime version: R2022b (9.13)
- Runtime link: https://www.mathworks.com/products/compiler/matlab-runtime.html

------------------------------------------------------------------------------------------
* Assign design files (Input.txt)
------------------------------------------------------------------------------------------
- Modify the 'Input.txt' file to assign design files.
- In the 'Input.txt' file, <lattice_type> and <file_directory> should be denoted.
- Use caDNAno design files (json and csv).
- The percentage mark ('%') represents comments
- Example designs were already assigned.

------------------------------------------------------------------------------------------
* How to run the program (Window)
------------------------------------------------------------------------------------------
- Execute 'SNUPI.exe'
- The example result files will be saved in the 'OUTPUT' folder.
- To analyze custom design files, modify 'Input.txt'

------------------------------------------------------------------------------------------
* How to run the program (Linux)
------------------------------------------------------------------------------------------
- Open the terminal
- Move the current directory to the SNUPI folder
- Give permission to execute
	chmod +x *
- Execute SNUPI
	./run_SNUPI.sh <mcr_directory>
- For example,
	./run_SNUPI.sh /usr/local/MATLAB/MATLAB_Runtime/R2022b
- The result files will be saved in the 'OUTPUT' folder.
- To analyze custom design files, modify 'Input.txt'

------------------------------------------------------------------------------------------
* How to run the program (Mac)
------------------------------------------------------------------------------------------
- Open the terminal
- Move the current directory to the SNUPI folder
- Give permission to execute
	chmod +x *
- Execute SNUPI in the FILE folder using Terminal
	./run_SNUPI.sh <mcr_directory>
- For example,
	./run_SNUPI.sh /Applications/MATLAB/MATLAB_Runtime/R2022b
- The result files will be saved in the 'OUTPUT' folder.
- To analyze custom design files, modify 'Input.txt'

------------------------------------------------------------------------------------------
* GPU acceleration
------------------------------------------------------------------------------------------
- GPU option is recommended for performing the dynamic simulation of large structures.
- GPU memory of more than 32GB is required for a DNA structure (> 7000 base-pairs).
- To use the GPU acceleration, change the option in the '.snp' files as
	DYN_GPU		1

------------------------------------------------------------------------------------------
* Restart simulation
------------------------------------------------------------------------------------------
- After static or dynamic simulations, the '<NAME>_RES.mat' file will be generated.
- To restart the simulation, set the restart file name to <NAME>_RES.mat, with the option
	DYN_INIT_CONF   3

------------------------------------------------------------------------------------------
* Technical details
------------------------------------------------------------------------------------------
- SNUPI framework (static analysis)
	Rapid computational analysis of DNA origami assemblies at near-atomic resolution, 
	ACS Nano 15.1 (2021)
- Improved model of single-stranded DNA
	Characterizing and harnessing the mechanical properties of short single-stranded DNA 
	in structured assemblies, ACS Nano 15.12 (2021)
- Partition and relocation framework (free-form structures)
	Predicting the free-form shape of structured DNA assemblies from their lattice-based 
	design blueprint, ACS Nano 16.3 (2022)
- Langevin dynamic analysis
	A computational model for structural dynamics and reconfiguration of DNA assemblies, 
	Nature Communications 14.1 (2023)
- Graph neural network (Deep SNUPI) 
	Data-driven and physics-informed prediction of DNA origami shape using graph neural 
	network, In revision.

