* SNUPI(Structured Nucleic Acids Programming Interface) is a multiscale analysis framework 
for nucleic acid nanostructures based on the finite element model 
with the intrinsic properties of DNA characterized by molecular dynamics simulation.

* Prerequisite
- The correct version of the MATLAB Runtime (version 9.6 (R2019a)) must be installed.
- Download link: "http://www.mathworks.com/products/compiler/mcr/index.html"
- Refer to 'Protocol.pdf' for more details.

* Procedure
- Modify 'Input.txt' to indicate a design file.
- In the 'Input.txt' file, <lattice_type> and <file_directory> should be written.
- To give a permission to execute,
	chmod +x *
- Execute SNUPI in the FILE folder
	./run_SNUPI.sh <mcr_directory>
- For example,
	./run_SNUPI.sh /usr/local/MATLAB/MATLAB_Runtime/v96

* Please cite the following paper when SNUPI is used.
- Rapid Computational Analysis of DNA Origami Assemblies at Near-Atomic Resolution, ACS Nano, 2021, DOI: 10.1021/acsnano.0c07717

* Update (v2.00, see Protocol.pdf)
- Partition and relocation framework: wireframe or closed structures can be analyzed by reconstructing the initial configuration.
- Single-stranded DNA: Mechanical properties of single-stranded DNA were characterized and incorporated.
- OxDNA: output files for further oxDNA simulation can be generated.


