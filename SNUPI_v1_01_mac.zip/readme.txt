* SNUPI(Structured Nucleic Acids Programming Interface) is a multiscale analysis framework for nucleic acid nanostructures based on the finite element model with the geometric and mechanical properties of DNA characterized by molecular dynamics simulation.  

* Prerequisite
- The correct version of the MATLAB Runtime (version 9.6 (R2019a)) must be installed.
- Download and install at "http://www.mathworks.com/products/compiler/mcr/index.html".

* Procedure
- Modify 'Input.txt' to indicate a design file.
- In the 'Input.txt' file, <lattice_type> and <file_directory> should be written.
- To give a permission to execute,
	chmod +x *
- Execute SNUPI in the FILE folder
	./run_SNUPI.sh <mcr_directory>
- For example,
    ./run_SNUPI.sh /Applications/MATLAB/MATLAB_Runtime/v96
- Refer to 'Protocol.pdf' for more details on the program.

* Please cite the following paper when SNUPI is used.
- Rapid Computational Analysis of DNA Origami Assemblies at Near-Atomic Resolution, ACS Nano, 2021, DOI: 10.1021/acsnano.0c07717
